#include"PQType.h"



PQType::PQType()  //constructor to create what is needed for the PQType
{
	maxItems = 50;
	items.fromCity = new string[50];
	items.toCity = new string[50];
	items.weight = new int[50];
	length = 0;
}

void PQType::MakeEmpty()  //make empty is less comlicated as it is recreated and destroyed after every shortest path call
{
	length = 0;
}

PQType::~PQType()  //more to delete, this should be changed to be a single item and not each element in the item
{
	delete [] items.fromCity;
	delete [] items.toCity;
	delete [] items.weight;
}

void PQType::Dequeue(ItemType& item)  //deque the first item and move positions in the que
{
	if(length == 0)
		throw EmptyPQ();
	else
	{
		item.fromCity = items.fromCity[0];
		items.fromCity[0] = items.fromCity[length - 1];
		item.toCity = items.toCity[0];
		items.toCity[0] = items.toCity[length - 1];
		item.distance = items.weight[0];
		items.weight[0] = items.weight[length - 1];
		length--;
		items.ReHeapDown(0, length - 1);
	}
}

void PQType::Enqueue(ItemType newItem)  //enque a new item into the que
{
	if(length == maxItems)
		throw FullPQ();
	else
	{
		length++;
		items.fromCity[length - 1] = newItem.fromCity;
		items.toCity[length - 1] = newItem.toCity;
		items.weight[length - 1] = newItem.distance;
		items.ReHeapUp(0, length - 1);
	}
}

bool PQType::IsFull() const
{
	return length == maxItems;
}

bool PQType::IsEmpty() const
{
	return length == 0;
}

inline void Swap(int& item1, int& item2, string& from1, string& from2, string& to1, string& to2)  //swapping all three elements, can be made easier to overload the operator and have one item = another item
{
	int tempItem;
	string tempString;
	tempItem = item1;
	item1 = item2;
	item2 = tempItem;
	tempString = from1;
	from1 = from2;
	from2 = tempString;
	tempString = to1;
	to1 = to2;
	to2 = tempString;
}


void HeapType::ReHeapDown(int root, int bottom)
{
	int maxChild;
	int rightChild;
	int leftChild;

	leftChild = root * 2 + 1;
	rightChild = root * 2 + 2;
	if(leftChild <= bottom)
	{
		if(leftChild == bottom)
			maxChild = leftChild;
		else
		{
			if(weight[leftChild] >= weight[rightChild])  //changes this to check the weight of the item being passed in and giving the lowest amount the highest priority
				maxChild = rightChild;
			else
				maxChild = leftChild;
		}
		if(weight[root] > weight[maxChild])  //change < to >
		{
			Swap(weight[root], weight[maxChild], fromCity[root], fromCity[maxChild], toCity[root], toCity[maxChild]);
			ReHeapDown(maxChild, bottom);
		}
	}
}

void HeapType::ReHeapUp(int root, int bottom)
{
	int parent;
	if(bottom > root)
	{
		parent = (bottom - 1) / 2;
		if(weight[parent] > weight[bottom])  //changes this to check the weight of the item being passed in and giving the lowest amount the highest priority
		{
			Swap(weight[parent], weight[bottom], fromCity[parent], fromCity[bottom], toCity[parent], toCity[bottom]);
			ReHeapUp(root, bottom);
		}
	}
}
//PQType class taken from the textbook chapter 9

#include"QueType.h"
using namespace std;

struct HeapType  //changed the HeapType to be a duplicate of the ItemType also being used
{
	void ReHeapDown(int root, int bottom);
	void ReHeapUp(int root, int bottom);
	string* toCity;
	string* fromCity;
	int* weight;
};

struct ItemType  //the item I am dealing with in PQType
{
	string fromCity;  //elements of flight path
	string toCity;
	int distance;
};




class FullPQ{};

class EmptyPQ{};

class PQType
{
public:
	PQType();
	~PQType();
	void MakeEmpty();
	bool IsEmpty() const;
	bool IsFull() const;
	void Enqueue(ItemType newItem);
	void Dequeue(ItemType& item);
	void PrintPQ();
	
private:
	int length;
	HeapType items;  
	int maxItems;
};